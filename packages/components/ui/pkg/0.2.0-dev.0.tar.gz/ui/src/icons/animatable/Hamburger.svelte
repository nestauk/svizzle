<script>
	export let open = false;

	function handleClick(e) {
		open = !open;
		console.log(open);
	}
</script>

<div class="hamburger" class:open on:click={handleClick}>
	<div class="top-bun"></div>
	<div class="meat"></div>
	<div class="bottom-bun"></div>
</div>

<style>
	.hamburger {
		--size: 24px;
		--bun-color: black;
		position: relative;
		width: var(--size);
		height: var(--size);
		box-sizing: border-box;
	}
	.hamburger > * {
		--bun-spacing: calc( var(--size) / 5 );
		--ham-center: calc(var(--bun-spacing) * 2);
		--corner-pos: calc(50% - var(--ham-center) * .1414);
		position: absolute;
		display: block;
		background: var(--bun-color);
		width: var(--size);
		height: var(--bun-spacing);
		border-radius: calc(var(--bun-spacing) / 2);
		transition: transform 200ms, width 200ms;
	}
	.meat {
		transform: translate(0, var(--ham-center));
	}
	.bottom-bun {
		transform: translate(0, calc(var(--bun-spacing) * 4));
	}
	.open .top-bun {
		transform:
			translate(0, var(--ham-center))
			rotate(45deg);
	}
	.open .meat {
		transform: translate(calc(var(--bun-spacing) * 2), calc(var(--bun-spacing) * 2));
		width: var(--bun-spacing);
	}
	.open .bottom-bun {
		transform:
			translate(0, calc(var(--bun-spacing) * 2))
			rotate(-45deg);
	}
</style>
